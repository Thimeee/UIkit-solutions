import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThemeService } from 'multi-ui-kit';
import { ButtonComponent } from 'multi-ui-kit';

@Component({
  selector: 'app-root', // ← MUST match <app-root> in index.html
  standalone: true,
  imports: [CommonModule, ButtonComponent],
  template: `
    <div style="padding: 40px; min-height: 100vh;">
      <h2 style="margin-bottom: 24px;">MUK Theme Demo</h2>

      <!-- Simple toggle button -->
      <div style="margin-bottom: 24px;">
        <muk-button
          variant="info"
          buttonStyle="ghost"
          (clicked)="theme.toggle()"
          [ariaLabel]="theme.isDark() ? 'Switch to light mode' : 'Switch to dark mode'"
        >
          {{ theme.isDark() ? '☀️ Light' : '🌙 Dark' }}
        </muk-button>
      </div>

      <!-- Three-state selector (light / dark / auto) -->
      <div style="display: flex; gap: 8px; margin-bottom: 32px;">
        <muk-button
          size="sm"
          [buttonStyle]="theme.mode() === 'light' ? 'solid' : 'ghost'"
          variant="success"
          (clicked)="theme.setMode('light')"
        >
          Light
        </muk-button>
        <muk-button
          size="sm"
          [buttonStyle]="theme.mode() === 'dark' ? 'solid' : 'ghost'"
          variant="warning"
          (clicked)="theme.setMode('dark')"
        >
          Dark
        </muk-button>
        <muk-button
          size="sm"
          [buttonStyle]="theme.mode() === 'auto' ? 'solid' : 'ghost'"
          variant="info"
          (clicked)="theme.setMode('auto')"
        >
          Auto
        </muk-button>
      </div>

      <p>Current mode: <strong>{{ theme.mode() }}</strong></p>
      <p>Resolved theme: <strong>{{ theme.resolved() }}</strong></p>
    </div>
  `,
})
export class AppComponent {
  theme = inject(ThemeService);
}